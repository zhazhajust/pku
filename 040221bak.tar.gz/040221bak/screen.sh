#!/bin/bash
python gifEy.py MassLimit/a10_w6
python gifEy.py MassLimit/a20_w3

