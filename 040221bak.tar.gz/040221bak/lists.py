import constant as const
import numpy as np
#lists=np.array(const.b)
line=const.b#lists[1:,0]
print(line.shape,line)
#for i in line:
#	print(i)
