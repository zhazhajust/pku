import numpy as np
import constant as const
import os
import multiprocessing
import lists
savedir = const.txtdir

#efficiency=np.load(savedir+'eff_bz.npy')

#a0=np.loadtxt(savedir+'a0.txt')
#print('a0.argmax():',a0.argmax())
#print('eff.argmax():',efficiency.argmax())
start = const.start
stop  = const.stop
step  = const.step
#b = const.x_max/3e8/const.dt_snapshot/2
try:
	b = (const.las_t_fwhm1/const.dt_snapshot)*2
except:
	b = 0
b = int(b)
print('b',b)
dirsdf  = const.sdfdir
dirsize =  const.filenumber
####
#stay=lists.line[::int(len(lists.line)/100)]
stay=np.arange(start,stop+int(stop)/100,int(stop)/100)
#print('1=2',stay/stay2)
def rm(n):
	save = 0

	#index_max = efficiency.argmax()+1
	#a0_max    = a0.argmax()+1
	#print('a0',a0.max())
	#print('eff',efficiency.max())

	str_n = str(n).zfill(const.filenumber)

	#if str_n in stay:
	if n in stay:
		save = 1
		print(str_n)
	if n == b: 
		save = 1
	if n == stop:
                save = 1
	#####remove
	
	if save == 0:
		if os.path.exists(dirsdf+str(n).zfill(dirsize)+".sdf")==True:
			print('begin_remove')
			os.remove(dirsdf+str(n).zfill(dirsize)+".sdf")
			print('remove:',n)
	if save == 1:
		print('save_sdf:',n)
	
	return
print('len(lists.line)',len(lists.line))
if len(lists.line) < const.stop:
	print('has been removed')


pool = multiprocessing.Pool(processes=96)
results=pool.map(rm,range(start,stop+step,step))
#print(len(results))


