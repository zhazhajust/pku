# -- coding: utf-8 --
import os
import sys
import numpy as np
#constant
nperseg = 256
case_name    = sys.argv[1]
data_name = case_name+"/"
#filenumber = 4
####
####

epochdir='/home/yujq/users/caijie/epoch2d'

####
####

sdfdir  =  epochdir+"/Data/"+data_name
#sdfdir  =  "../Data/"+data_name
txtdir  =  epochdir+"/txt/"+data_name
figdir  =  epochdir+"/fig/"+data_name
gifdir  =  epochdir+"/gif/"+data_name
pngdir  =  epochdir+"/gif/png/"
####stop
a=os.listdir(sdfdir)
a=[i.split('.') for i in a]
loop=[i for i in a if i[1] == 'sdf']
loop=np.array(loop)
#loop=np.sort(loop)
loop=loop[:,0]
loop=np.sort(loop)

b=loop

start=1
stop=int(b[-1])
step=1
print(stop)
filenumber = len(str(b[-1]))

def checkdir():
    
    if (os.path.isdir(txtdir) == False):
            os.makedirs(txtdir,exist_ok = True)
    if (os.path.isdir(figdir) == False):
            os.makedirs(figdir,exist_ok = True)
    os.makedirs(gifdir,exist_ok = True)
    os.makedirs(pngdir,exist_ok = True)
checkdir()

######

fb=open(sdfdir+'deck.status','r')
www=fb.readlines()
www=[i.replace(' \tElement ','').replace(' handled OK\n','') for i in www]
www=[i.split('=') for i in www]
new_dict={}
for i in www:
    if len(i) == 2:
        new_dict[i[0]] = i[1]
locals().update(new_dict)
#####
#####
name=case_name






######
######
micron=1e-6
c=3e8
femto=1e-15
Nx=eval(nx)
laser_lamada=eval(laser_lamada)

T0=eval(T0)
Ny=eval(ny)
#Nz=eval(nz)
y_min=eval(y_min)
y_max=eval(y_max)
x_min=eval(x_min)
x_max=eval(x_max)
#z_min=eval(z_min)
#z_max=eval(z_max)
dt_snapshot=eval(dt_snapshot)
window_start_time=eval(window_start_time)
las_t_fwhm1=eval(las_t_fwhm1)


print(las_t_fwhm1,dt_snapshot)
lamada=laser_lamada
########
####stop
#a=os.listdir(sdfdir)
#a=[i.split('.') for i in a]
#b=[i for i in a if i[1] == 'sdf']
#stop=int(b[-1][0])
print(stop)
###
###
start   =  1
###
'''
c       =  3e8
micron  =  1e-6
lamada  =  10.6 * micron 
gridnumber = 1908
Ny      =  235
Nx      =  gridnumber
Nz      =  235

start   =  1
stop    =  4000
step    =  1
'''


dt      =  dt_snapshot*1e15      #fs
x_end   =  x_max - x_min 
y_lenth =  y_max - y_min #lamada
#z_lenth =  z_max - z_min 
#print(window_start_time)
#window_start_time =  (x_max - x_min) / c
delta_x =  x_end/Nx
delta_y =  y_lenth/Ny
t_end   =  stop * dt_snapshot
x_interval=1
t_total=1e15*x_end/c         #fs
#print(t_total,dt_snapshot)
t_size=t_total/(dt_snapshot*1e15)+1+1           #t_grid_number
######t_size=int(1e15*gridnumber*delta_x/c)+1

if t_end-window_start_time<0:
      xgrid   =  int(Nx)
else:
      xgrid   =  int(Nx + c*(t_end-window_start_time)/delta_x)
#####fft freqs


